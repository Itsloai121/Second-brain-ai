from __future__ import annotations
import json, re, sqlite3
from pathlib import Path
from typing import Any
from fastapi import FastAPI, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn

ROOT = Path(__file__).resolve().parent
DB = ROOT / 'data' / 'brain.db'
UPLOADS = ROOT / 'data' / 'uploads'
DB.parent.mkdir(exist_ok=True)
UPLOADS.mkdir(exist_ok=True)

ORG = {
    'name': 'Product & Design', 'employees': 15,
    'mission': 'Determines what should be built, why, how users interact with it, and whether it solves the intended problem.',
    'teams': [
        ('Product Management', 6, 'Director 1 • Senior PMs 2 • PMs 2 • Analyst 1', 'Product strategy, prioritization and ownership.'),
        ('UX/UI Design', 5, 'Design Lead 1 • UX 2 • UI 2', 'User experience and interface design.'),
        ('Product Research', 2, 'UX Researcher 1 • Market/Product Researcher 1', 'User and market research.'),
        ('Technical Writing / Documentation', 2, 'Technical Writer 1 • Documentation Specialist 1', 'Technical product documentation.'),
    ],
}

LAYERS = {
    'Business Knowledge & Documents': ['Policies','SOPs','Procedures','Contracts','Training','Manuals','Reports','Internal Knowledge','Historical Records'],
    'Business Data': ['Customers','Products/Services','Employees','Sales','Financial Data','Operational Data','Performance Data','Supplier Data','Other Business Data'],
    'Events & Activity': ['Transactions','Customer Activity','Operational Events','Communications','Status Changes','Incidents','Decisions','System Events','User Activity'],
    'Data Ingestion': ['Documents / Files','Spreadsheets / CSV','APIs','Business Applications','Databases','CRM / ERP / HR Systems','Communication Platforms','Manual Input','Real-Time Events'],
    'Data Processing': ['Parsing','Validation','Cleaning','Normalization','Deduplication','Classification','Entity Extraction','Metadata Extraction','Enrichment'],
    'Knowledge Layer': ['SQL / Relational Data','Vector Index','Document Store','Metadata','Entity Relationships','Knowledge Graph*','Business Ontology'],
    'Security & Governance': ['Authentication','Authorization','RBAC / ABAC','Data Isolation','Permission Enforcement','Audit Logging','Data Governance','Privacy Controls','Policy Enforcement'],
    'User / Role Context': ['User Identity','Role','Department','Responsibilities','Permissions','Current Task','Goals','Preferences','Organizational Context'],
    'Request / Task': ['Question','Search','Investigation','Analysis','Decision Support','Forecasting','Planning','Reporting','Action Request'],
    'Query / Task Understand': ['Intent Detection','Entity Extraction','Query Rewriting','Time / Scope Detection','Permission Verification','Task Decomposition','Required Data Identification'],
    'Retrieval Engine': ['Semantic Search','Keyword Search','SQL Retrieval','Metadata Filtering','Relationship Retrieval','Graph Traversal*','Hybrid Retrieval','Reranking'],
    'Memory System': ['Short-Term','Long-Term','Episodic','Semantic','User Memory','Decision History','Lessons'],
    'Business Intelligence': ['Calculations','Analytics','KPIs','Forecasting','Optimization','Business Rules','Simulations','Comparisons'],
    'Context / State': ['Current State','Active Tasks','User Context','Workflow State','Previous Steps','Pending Actions','Session Context'],
    'AI Reasoning': ['Foundation Model / LLM','Context Assembly','Reasoning','Planning','Business Rules','Calculations','Memory Integration','Uncertainty Handling','Evidence Evaluation','Constraint Enforcement'],
    'Agent / Tool Layer': ['Search Tools','Database Tools','Analytics Tools','Forecasting Tools','Reporting Tools','CRM Tools','ERP Tools','Communication Tools','Workflow Tools','Notification Tools','External APIs','Authorized Action Tools*'],
    'Second-Brain Platform': ['Understand','Remember','Retrieve','Analyze','Reason','Detect Problems','Explain','Recommend','Predict','Plan','Simulate','Report','Coordinate','Take Authorized Actions*'],
    'Specialized Second-Brain Layer': ['Sales Brain','Marketing Brain','Operations Brain','Finance Brain','HR Brain','Support Brain','Management Brain','Other Function-Specific Brains'],
    'Response / Decision': ['Answer','Evidence / Sources','Analysis','Recommendation','Calculations','Confidence / Uncertainty','Proposed Action','Reasoning Summary'],
    'User Interface': ['AI Chat','Dashboards','Reports','Analytics','Alerts','Search'],
    'Action / Approval': ['Human Approval','Authorized Actions','Notifications','Workflow Execution','System Updates','External Actions'],
    'Feedback & Evaluation': ['User Feedback','Human Corrections','Outcome Tracking','Answer Evaluation','Retrieval Evaluation','Tool Evaluation','Decision Evaluation','Agent Evaluation','Error Detection','Business KPI Evaluation'],
    'Knowledge / Memory Update': ['New Facts','New Decisions','Corrections','Lessons Learned','Updated Documents','Changed Business State','New Relationships','Updated Rules'],
}

COMMANDS = {
    '/status':'Show current role, task, memory, and system health.', '/org':'Summarize the Product & Design organization and responsibilities.', '/teams':'List the four teams, staffing, and primary responsibilities.', '/layers':'Explain the Second Brain architecture from ingestion to feedback loop.', '/remember':'Store a user memory or decision note in local memory.', '/memory':'Show recent memory entries and lessons.', '/search':'Search the local knowledge base using hybrid keyword retrieval.', '/plan':'Decompose a product goal into an actionable plan.', '/analyze':'Return structured analysis with evidence, risks, and recommendations.', '/report':'Generate a concise executive-style report.', '/simulate':'Create a lightweight scenario simulation and assumptions.', '/help':'Open the commands and functions reference.'
}

app = FastAPI(title='Second Brain AI Engine', version='0.1.0')
app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_methods=['*'], allow_headers=['*'])

class ChatRequest(BaseModel):
    message: str
    role: str = 'Product & Design'


def db():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    c.execute('CREATE TABLE IF NOT EXISTS memory (id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL, kind TEXT DEFAULT "semantic", created_at DATETIME DEFAULT CURRENT_TIMESTAMP)')
    c.execute('CREATE TABLE IF NOT EXISTS documents (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, path TEXT, content TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)')
    c.commit(); return c


def memory_rows(limit=8):
    c=db(); rows=c.execute('SELECT * FROM memory ORDER BY id DESC LIMIT ?', (limit,)).fetchall(); c.close(); return [dict(r) for r in rows]


def add_memory(text: str, kind='semantic'):
    c=db(); c.execute('INSERT INTO memory(text,kind) VALUES(?,?)',(text,kind)); c.commit(); c.close()


def search_docs(term: str):
    c=db(); rows=c.execute('SELECT name, content FROM documents').fetchall(); c.close()
    tokens=[t.lower() for t in re.findall(r'\w+',term) if len(t)>2]
    scored=[]
    for r in rows:
        s=r['content'].lower(); score=sum(s.count(t) for t in tokens)
        if score: scored.append((score,r['name']))
    return [x[1] for x in sorted(scored, reverse=True)[:5]]


def help_text():
    return 'Commands: ' + ' • '.join(f'{k} — {v}' for k,v in COMMANDS.items())


def command_reply(msg: str):
    lower=msg.lower().strip()
    if lower == '/status':
        return ('System status: Product & Design role active. Python AI engine, SQLite memory store, local knowledge inbox, and role-aware command router are ready.', 'status', ['Role: Product & Design (15 employees)','Schema: ingestion → processing → knowledge → retrieval → reasoning → tools → response → feedback'], ['Ask /teams','Use /layers'])
    if lower == '/org':
        return (f"{ORG['name']} has {ORG['employees']} employees. Mission: {ORG['mission']}", 'organization', ['Source: info.txt — Product & Design — 15 Employees'], ['Ask /teams','Ask for a /report'])
    if lower == '/teams':
        text='; '.join(f'{a} ({b}): {d}' for a,b,_,d in ORG['teams'])
        return (text, 'organization', ['Product Management 6','UX/UI Design 5','Product Research 2','Technical Writing / Documentation 2'], ['Use /plan for a cross-team goal'])
    if lower == '/layers':
        return ('The brain follows the supplied architecture: business knowledge/data/events → ingestion → processing → structured/unstructured knowledge → security/governance → user/role context → request understanding → retrieval → memory + business intelligence + state → AI reasoning → agent/tools → Second-Brain platform → specialized brain → response/decision → UI/action approval → real-world outcome → feedback/evaluation → knowledge/memory update.', 'architecture', ['Source: second brain ai schema.txt','Optional advanced pieces are marked with * in the source schema'], ['Ask /search <term>','Ask /analyze <topic>'])
    if lower == '/memory':
        rows=memory_rows(); body='\n'.join(f"• {r['text']}" for r in rows) if rows else 'No additional memories stored yet.'
        return (body, 'memory', ['SQLite local memory table'], ['Use /remember <fact> to add a memory'])
    if lower == '/help':
        return (help_text(), 'help', ['Command router is local and role-aware'], ['Try /status','Try /layers'])
    if lower.startswith('/remember '):
        fact=msg[10:].strip(); add_memory(fact,'user'); return (f'Stored memory: {fact}', 'memory_write', ['Saved to SQLite memory store'], ['Run /memory to review it'])
    if lower.startswith('/search '):
        term=msg[8:].strip(); hits=search_docs(term); return (f'Knowledge search for "{term}": ' + (', '.join(hits) if hits else 'no uploaded documents matched yet.'), 'retrieval', ['Hybrid baseline: keyword + local document metadata'], ['Upload a document in Knowledge','Refine the search term'])
    if lower.startswith('/plan '):
        goal=msg[6:].strip(); return (f'Plan for: {goal}\n1) Clarify desired outcome and constraints.\n2) Identify stakeholders across Product Management, UX/UI, Research, and Documentation.\n3) Retrieve relevant knowledge and prior decisions.\n4) Generate options and evaluate trade-offs.\n5) Confirm human approval points.\n6) Report the decision and feed outcome back into memory.', 'planning', ['Role context: Product & Design','Schema layers: task understanding → retrieval → reasoning → approval → feedback'], ['Add a decision with /remember','Ask /report <topic>'])
    if lower.startswith('/analyze '):
        topic=msg[9:].strip(); return (f'Analysis: {topic}\n• Context: Product & Design owns what to build, why, interaction quality, and problem-solution fit.\n• Questions: desired user outcome, evidence strength, constraints, ownership, measurement.\n• Risks: unclear problem definition, weak evidence, cross-team handoff gaps.\n• Recommendation: use research + product strategy + UX evidence before committing; document the decision and follow the feedback loop.', 'analysis', ['Source: info.txt mission and team responsibilities','Source: second brain ai schema.txt reasoning, evidence, constraints, feedback'], ['Turn this into a /plan','Store a decision with /remember'])
    if lower.startswith('/report '):
        topic=msg[8:].strip(); return (f'Executive report — {topic}\nPurpose: provide a decision-ready summary for Product & Design.\nCurrent context: 15-person function across Product Management, UX/UI Design, Product Research, and Technical Writing/Documentation.\nDecision lens: customer/user value, feasibility, evidence, experience quality, ownership, and measurable outcome.\nNext step: validate evidence, align owners, approve action, then evaluate the outcome and update memory.', 'reporting', ['Source: info.txt — staffing and responsibilities','Schema output: answer, evidence, analysis, recommendation, confidence, proposed action'], ['Ask /analyze <topic>','Ask /plan <goal>'])
    if lower.startswith('/simulate '):
        sc=msg[10:].strip(); return (f'Simulation setup for: {sc}\nAssumptions: stable team structure, role permissions intact, and outcomes measured after execution.\nScenario A: move forward now → faster learning, higher risk if evidence is weak.\nScenario B: research first → slower start, stronger evidence.\nScenario C: pilot → balanced learning and risk control.', 'simulation', ['Schema supports simulations as an advanced business-intelligence capability'], ['Ask /analyze the scenario','Store the chosen scenario'])
    if lower in ('hi','hello','hey','start'):
        return ('Hello. I’m ready for Product & Design questions, planning, analysis, reporting, memory, and schema-aware commands. Type /help to see the command set.', 'greeting', ['Role: Product & Design'], ['Ask /status','Ask /teams'])
    return (f'I understand this as a Product & Design task: "{msg}". I can reason over the supplied organization context and Second Brain schema, but for document-grounded answers I need relevant files in the local knowledge inbox. Try /org, /teams, /layers, /plan <goal>, /analyze <topic>, or /search <term>.', 'general', ['Role context: Product & Design','Local knowledge retrieval is enabled when documents are uploaded'], ['Open Commands & Functions','Upload knowledge'])

@app.get('/api/health')
def health():
    db().close(); return {'ok': True, 'service': 'second-brain-ai-engine', 'role': ORG['name']}

@app.post('/api/chat')
def chat(req: ChatRequest):
    answer,intent,evidence,actions=command_reply(req.message)
    return {'answer': answer, 'intent': intent, 'confidence': 0.92 if req.message.strip().startswith('/') else 0.78, 'evidence': evidence, 'suggested_actions': actions}

@app.get('/api/memory')
def memories(): return {'items': memory_rows()}

@app.post('/api/knowledge/upload')
async def upload(file: UploadFile = File(...)):
    content = (await file.read()).decode('utf-8', errors='ignore')
    target = UPLOADS / re.sub(r'[^a-zA-Z0-9._-]','_', file.filename or 'document.txt')
    target.write_text(content, encoding='utf-8')
    c=db(); c.execute('INSERT INTO documents(name,path,content) VALUES(?,?,?)',(file.filename,str(target),content[:200000])); c.commit(); c.close()
    return {'ok': True, 'name': file.filename, 'chars': len(content)}

@app.get('/api/commands')
def commands(): return {'commands':[{'command':k,'description':v} for k,v in COMMANDS.items()]}

if __name__ == '__main__':
    uvicorn.run(app, host='127.0.0.1', port=8787)
