#!/usr/bin/env bash
python3 backend/main.py
