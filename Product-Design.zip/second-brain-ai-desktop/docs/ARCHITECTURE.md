# Architecture mapping

The implementation follows the supplied Second Brain schema as a two-layer system:

- GUI: React/TypeScript glassmorphism desktop interface.
- Backend: Python AI/data service + SQLite, exposed over localhost to the Tauri shell.

The supplied schema's optional advanced pieces (knowledge graphs, autonomous actions, multi-agent coordination, advanced forecasting, optimization, simulations) are represented as extension points rather than silently pretending they are implemented.
