import { Bell, CircleHelp, Command, Search, ShieldCheck } from 'lucide-react';
import { org } from '../data/knowledge';

export function Topbar({ backendOnline, onCommands }: { backendOnline: boolean; onCommands: () => void }) {
  return (
    <header className="topbar">
      <div className="search-box"><Search size={17} /><input placeholder="Search knowledge, teams, memories…"/><kbd>⌘ K</kbd></div>
      <div className="top-actions">
        <button className="icon-btn" title="Commands" onClick={onCommands}><Command size={17} /></button>
        <button className="icon-btn" title="Help"><CircleHelp size={17} /></button>
        <button className="icon-btn" title="Notifications"><Bell size={17} /></button>
        <div className="status-pill"><span className={`status-dot ${backendOnline ? 'online' : 'offline'}`}/>{backendOnline ? 'AI Engine Online' : 'UI Mode'}</div>
        <div className="avatar">PD</div>
      </div>
    </header>
  );
}
