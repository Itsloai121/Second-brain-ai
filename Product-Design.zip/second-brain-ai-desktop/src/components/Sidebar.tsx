import { BrainCircuit, Command, Database, FileText, LayoutDashboard, MessageSquare, Settings2, Sparkles } from 'lucide-react';

type Page = 'overview' | 'chat' | 'knowledge' | 'memory' | 'commands' | 'settings';

export function Sidebar({ page, setPage }: { page: Page; setPage: (p: Page) => void }) {
  const items: { id: Page; label: string; icon: typeof LayoutDashboard }[] = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'chat', label: 'AI Chat', icon: MessageSquare },
    { id: 'knowledge', label: 'Knowledge', icon: Database },
    { id: 'memory', label: 'Memory', icon: BrainCircuit },
    { id: 'commands', label: 'Commands & Functions', icon: Command },
    { id: 'settings', label: 'Settings', icon: Settings2 },
  ];
  return (
    <aside className="sidebar">
      <div className="brand" onClick={() => setPage('overview')}>
        <div className="brand-orb"><Sparkles size={18} /></div>
        <div><div className="brand-title">Second Brain</div><div className="brand-sub">PRODUCT & DESIGN</div></div>
      </div>
      <nav>
        <div className="nav-caption">WORKSPACE</div>
        {items.map(({ id, label, icon: Icon }) => (
          <button key={id} className={`nav-item ${page === id ? 'active' : ''}`} onClick={() => setPage(id)}>
            <Icon size={17} /><span>{label}</span>
          </button>
        ))}
      </nav>
      <div className="sidebar-footer"><FileText size={15} /><span>Local-first knowledge</span></div>
    </aside>
  );
}
