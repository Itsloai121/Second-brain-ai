export type ChatResponse = {
  answer: string;
  intent: string;
  confidence: number;
  evidence: string[];
  suggested_actions: string[];
  memory_added?: boolean;
};

const API_BASE = 'http://127.0.0.1:8787/api';

export async function healthCheck() {
  try {
    const response = await fetch(`${API_BASE}/health`, { signal: AbortSignal.timeout(900) });
    return response.ok;
  } catch {
    return false;
  }
}

export async function chat(message: string, role = 'Product & Design'): Promise<ChatResponse> {
  const response = await fetch(`${API_BASE}/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message, role }),
  });
  if (!response.ok) throw new Error(`Backend returned ${response.status}`);
  return response.json();
}

export async function uploadKnowledge(file: File) {
  const form = new FormData();
  form.append('file', file);
  const response = await fetch(`${API_BASE}/knowledge/upload`, { method: 'POST', body: form });
  if (!response.ok) throw new Error(`Upload failed (${response.status})`);
  return response.json();
}
