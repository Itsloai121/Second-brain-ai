import { useEffect, useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { Topbar } from './components/Topbar';
import { Overview, ChatPage, KnowledgePage, MemoryPage, CommandsPage, SettingsPage } from './pages';
import { healthCheck } from './lib/api';

type Page = 'overview' | 'chat' | 'knowledge' | 'memory' | 'commands' | 'settings';
export default function App(){
  const [page,setPage]=useState<Page>('overview'); const [online,setOnline]=useState(false);
  useEffect(()=>{ let active=true; const check=async()=>{const ok=await healthCheck(); if(active)setOnline(ok)}; check(); const id=setInterval(check,5000); return()=>{active=false;clearInterval(id)};},[]);
  const title=({overview:'Overview',chat:'AI Chat',knowledge:'Knowledge Layer',memory:'Memory',commands:'Commands & Functions',settings:'Settings'} as const)[page];
  return <div className="app-shell"><div className="ambient a1"/><div className="ambient a2"/><Sidebar page={page} setPage={setPage}/><div className="main-shell"><Topbar backendOnline={online} onCommands={()=>setPage('commands')}/><main><div className="page-heading"><div><div className="eyebrow">{title.toUpperCase()}</div>{page!=='overview'&&<h1>{title}</h1>}</div><div className="role-badge">ROLE · PRODUCT & DESIGN</div></div>{page==='overview'&&<Overview onChat={()=>setPage('chat')} onCommands={()=>setPage('commands')}/>} {page==='chat'&&<ChatPage/>}{page==='knowledge'&&<KnowledgePage/>}{page==='memory'&&<MemoryPage/>}{page==='commands'&&<CommandsPage/>}{page==='settings'&&<SettingsPage/>}</main></div></div>
}
