# Second Brain AI Desktop

A desktop-first Second Brain AI system for the **Product & Design** function, built directly from the supplied `ai schema`, `info`, `ui_design`, and `programming languages` specifications.

## Stack
- GUI: React + TypeScript + HTML/CSS
- Desktop shell: Tauri + Rust
- AI/data service: Python + FastAPI
- Local storage: SQLite
- Config/assets: JSON / YAML / TOML
- C/C++: not required in this build

## Included
- Glassmorphism UI using the requested palette: `#0F172A`, `#1E293B`, `#334155`, `#E2E8F0`, `#8B5CF6`.
- Product & Design role context based on the supplied 15-person organization.
- Schema browser covering ingestion, processing, knowledge, governance, retrieval, memory, reasoning, tools, response, approval, feedback, and continuous improvement.
- Role-aware chatbot with command router and structured evidence/action suggestions.
- Commands & Functions page.
- Local SQLite memory and document upload/retrieval baseline.
- Custom application icon (`icon.svg`, `icon.ico`, `icon.png`).

## Run in development
1. Install Node.js 20+.
2. Install Rust + Cargo and Tauri prerequisites for your OS.
3. Create a Python virtual environment and install the backend packages:

   ```bash
   cd second-brain-ai-desktop
   python -m venv .venv
   # Windows PowerShell
   .venv\\Scripts\\Activate.ps1
   # macOS/Linux
   source .venv/bin/activate
   pip install -r backend/requirements.txt
   ```

4. Install frontend packages:

   ```bash
   npm install
   ```

5. Start the Tauri app:

   ```bash
   npm run tauri:dev
   ```

The Tauri `beforeDevCommand` starts both the Python engine (`127.0.0.1:8787`) and Vite (`127.0.0.1:1420`).

## Run the web UI without Tauri

```bash
npm run dev:stack
```

## Build the desktop app

```bash
npm run tauri:build
```

The installers/bundles will be produced by Tauri under `src-tauri/target/release/bundle/`.

## Chatbot commands
See **Commands & Functions** inside the app. Core examples:
- `/status`
- `/org`
- `/teams`
- `/layers`
- `/remember <fact>`
- `/memory`
- `/search <term>`
- `/plan <goal>`
- `/analyze <topic>`
- `/report <topic>`
- `/simulate <scenario>`
- `/help`

## AI provider note
This package is intentionally local-first: the included Python engine provides deterministic role-aware routing and document retrieval. An external LLM provider can be added later behind the same `/api/chat` contract without changing the desktop UI.
